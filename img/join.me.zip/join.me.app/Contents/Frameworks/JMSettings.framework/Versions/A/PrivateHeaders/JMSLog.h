//
//  JMLog.h
//  JMSettings
//
//  Created by thonfi on 10/04/15.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

//@import Security;

#import "JMSLogger.h"

static inline void JMSLog_(JMSLogger logger, JMSLogLevel logLevel, NSString *formatString, ...)
{
    @autoreleasepool {
        if (!logger)
            return;
        
        va_list args;
        va_start(args, formatString);
        NSString *message = [[NSString alloc] initWithFormat:formatString arguments:args];
        va_end(args);
        
        logger(logLevel, message);
        [message release];
    }
}

#define JMSNoLog(logger, format, args...) 0
#define JMSTrace(logger, format, args...) JMSLog_(logger, JMSLogLevelTrace, format, ##args)
#define JMSDebug(logger, format, args...) JMSLog_(logger, JMSLogLevelDebug, format, ##args)
#define JMSInfo(logger, format, args...) JMSLog_(logger, JMSLogLevelInfo, format, ##args)
#define JMSWarn(logger, format, args...) JMSLog_(logger, JMSLogLevelWarning, format, ##args)
#define JMSError(logger, format, args...) JMSLog_(logger, JMSLogLevelError, format, ##args)
#define JMSCritical(logger, format, args...) JMSLog_(logger, JMSLogLevelCritical, format, ##args)

static inline void
JMSLogSecError(JMSLogger logger, bool error, OSStatus status, NSString *format, ...)
{
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);

    CFStringRef errorMessage = SecCopyErrorMessageString(status, NULL);
    if (error) {
        JMSError(logger, @"%@: %@ (%d)", message, errorMessage, status);
    }
    else {
        JMSDebug(logger, @"%@: %@ (%d)", message, errorMessage, status);
    }
    CFRelease(errorMessage);
    [message release];
}

