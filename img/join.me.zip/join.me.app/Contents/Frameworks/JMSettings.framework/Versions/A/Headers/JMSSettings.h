//
//  JMSSettings.h
//  JMSettings
//
//  Created by Károly Lőrentey on 2015-04-16.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <JMSettings/JMSLogger.h>

CF_EXTERN_C_BEGIN

/// The bundle identifier of the join.me application.
extern NSString *const kJoinMeApplicationBundleID;

@class JMSSettingsConfig;

@interface JMSSettings : NSObject
{
@private
    JMSLogger _logger;
    JMSSettingsConfig *_config;
}

/// Initializes a new settings instance with the specified logger. The instance will be configured with the default join.me configuration.
/// @param logger The settings instance will call this block to log messages.
- (instancetype)initWithLogger:(JMSLogger)logger;

/// Initializes a new settings instance with the specified logger and configuration.
/// This method is exposed only to support unit testing; you shouldn't need to use it in production code.
/// @param logger The settings instance will call this block to log messages.
- (instancetype)initWithLogger:(JMSLogger)logger config:(JMSSettingsConfig *)config NS_DESIGNATED_INITIALIZER;

/// A unique ID that identifies this particular computer.
@property (nonatomic, readonly) NSString *computerID;

/// YES if the running app's code has not been tampered with (i.e., the code signature is still valid).
@property (nonatomic, readonly) BOOL appSignatureIsValid;


/// Load a persistent setting.
/// @param name is the name of the setting.
/// @param domain is the site name for account-related settings (e.g. secure.join.me, jmmaster.dev.3amlabs.net, etc) or nil for settings not related to the user account.
/// @return the setting value or nil if the setting doesn't exist.
- (NSString *)persistentSetting:(NSString *)name withDomain:(NSString *)domain;

/// Set a persistent setting.
/// @param name is the name of the setting.
/// @param domain is the site name (for account-related settings) or nil
- (void)setPersistentSetting:(NSString *)name withDomain:(NSString *)domain toValue:(NSString *)value;



/// Returns YES if the specified secure setting exists in the keychain.
/// @param name is the name of the secure setting.
/// @param domain is the site name
- (BOOL)hasSecureSetting:(NSString *)name withDomain:(NSString *)domain;

/// Returns the value of the specified secure setting.
/// @param name is the name of the secure setting.
/// @param domain is the site name
/// @return the value of the setting or nil if the setting doesn't exist or if it's not accessible.
- (NSString *)secureSetting:(NSString *)name withDomain:(NSString *)domain;

/// Set a secure setting.
/// @param name is the name of the secure setting.
/// @param domain is the site name
- (void)setSecureSetting:(NSString *)name withDomain:(NSString *)domain toValue:(NSString *)value;

/// Returns an NSURL that points to the specified application.
/// @see kJoinMeApplicationBundleID
/// @param bundleID is the bundle id of the application
/// @return an NSURL that points to the application bundle
- (NSURL *)resolveBookmarkToApplicationWithBundleID:(NSString *)bundleID;

/// Save a bookmark that points to the specified application.
/// You normally don't need to call this method, as JMSSettings automatically saves a bookmark to the running app's main bundle when it is initialized.
/// @param bundleID is the bundle id of the application
/// @param URL the location of the application
- (void)storeBookmarkToApplicationWithBundleID:(NSString *)bundleID toURL:(NSURL *)URL;

@end

CF_EXTERN_C_END
