//
//  JMSLogger.h
//  JMSettings
//
//  Created by Károly Lőrentey on 2015-04-15.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

#ifndef JMSettings_JMSLogger_h
#define JMSettings_JMSLogger_h

#import <CoreFoundation/CoreFoundation.h>

CF_EXTERN_C_BEGIN

typedef CF_ENUM(int, JMSLogLevel) {
    JMSLogLevelCritical,
    JMSLogLevelError,
    JMSLogLevelWarning,
    JMSLogLevelInfo,
    JMSLogLevelDebug,
    JMSLogLevelTrace,
};

// A logger block.
typedef void (^JMSLogger)(JMSLogLevel logLevel, NSString *message);

CF_EXTERN_C_END

#endif // JMSettings_JMSLogger_h
